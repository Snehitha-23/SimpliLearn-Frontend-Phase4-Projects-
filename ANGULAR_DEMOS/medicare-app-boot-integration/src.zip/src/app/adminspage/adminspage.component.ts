import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminspage',
  templateUrl: './adminspage.component.html',
  styleUrls: ['./adminspage.component.css']
})
export class AdminspageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
