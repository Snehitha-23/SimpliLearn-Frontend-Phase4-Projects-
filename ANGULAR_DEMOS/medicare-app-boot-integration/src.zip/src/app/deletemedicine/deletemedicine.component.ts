import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletemedicine',
  templateUrl: './deletemedicine.component.html',
  styleUrls: ['./deletemedicine.component.css']
})
export class DeletemedicineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
