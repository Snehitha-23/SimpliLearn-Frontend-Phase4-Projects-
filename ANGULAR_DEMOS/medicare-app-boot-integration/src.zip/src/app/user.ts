export class User {
     id:number;
     name:string;
     address:string;
      age:number;
      emailId:string;
      pwd:string;	





}
