export class Medicine {
     id:number;
     name:string;
     price:number;
     seller:string;
     productDescription:string;
     instructions:string;
     avatar:string;


}
